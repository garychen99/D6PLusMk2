#include "ultralcd.h"
#include "cardreader.h"
#include "temperature.h"
#include "stepper.h"
#include "UltiLCD2_hi_lib.h"
#include "UltiLCD2_menu_material.h"
#include "UltiLCD2_menu_first_run.h"
#include "UltiLCD2_menu_print.h"
#include "UltiLCD2_menu_maintenance.h"
#include "mesh_bed_leveling.h"
#ifdef DEVELOPER_MODE
#define LCD_PROBE_Z_RANGE 4
static uint8_t manual_probe_index;
const float manual_feedrate_mm_m[] = { 50 * 60, 50 * 60, 4 * 60, 60 };
static void lcd_menu_bed_leveling_complete()
{
    void bed_leveling_home_move();
    #if 0
    lcd_basic_screen();
    #else
    lcd_info_screen(lcd_menu_main, bed_leveling_home_move, PSTR("Return"));
    #endif
    lcd_lib_draw_string_centerP(20, PSTR("Bed level complete."));
    lcd_lib_update_screen();
}
inline void line_to_current(AxisEnum axis) {
    planner.buffer_line_kinematic(current_position, MMM_TO_MMS(manual_feedrate_mm_m[axis]), active_extruder);
}
inline void myMoveToXy(float x, float y) {
    current_position[Z_AXIS] = LOGICAL_Z_POSITION(LCD_PROBE_Z_RANGE+Z_HOMING_HEIGHT);
    line_to_current(Z_AXIS);
    current_position[X_AXIS] = LOGICAL_X_POSITION(x);
    current_position[Y_AXIS] = LOGICAL_Y_POSITION(y);
    planner.buffer_line_kinematic(current_position, MMM_TO_MMS(XY_PROBE_SPEED), active_extruder);
    #if Z_HOMING_HEIGHT > 0
    current_position[Z_AXIS] = LOGICAL_Z_POSITION(LCD_PROBE_Z_RANGE);
    line_to_current(Z_AXIS);
    #endif
}
static void lcd_menu_bed_leveling_showMoving()
{
    void lcd_menu_bed_leveling_run();
    #if 0
    lcd_basic_screen();
    #else
    lcd_info_screen(NULL, NULL, PSTR("Mannual bed leveling"));
    #endif
    lcd_lib_draw_string_centerP(10, PSTR("Moving..."));
    lcd_lib_draw_string_centerP(20, PSTR("Go to next point"));
    char str[8];
    int total = (GRID_MAX_POINTS_X)* (GRID_MAX_POINTS_Y);
    sprintf(str, "%i/%i", manual_probe_index,total);
    lcd_lib_draw_string_center(30, str);
    lcd_lib_update_screen();
    if (!planner.blocks_queued())
    {
        mbl.set_zigzag_z(manual_probe_index - 1, current_position[Z_AXIS]);
        if (manual_probe_index == total)lcd_change_to_menu(lcd_menu_bed_leveling_complete);
        else lcd_change_to_menu(lcd_menu_bed_leveling_run);
    }
}
static void bed_leveling_run_move()
{
    manual_probe_index++;
    int8_t px, py;
    mbl.zigzag(manual_probe_index - 1, px, py);
    myMoveToXy(LOGICAL_X_POSITION(mbl.index_to_xpos[px]),
        LOGICAL_Y_POSITION(mbl.index_to_ypos[py]));
}
static void levelingMove()
{
    manual_probe_index++;
    switch (manual_probe_index)
    {
    case 1:
        myMoveToXy(85, 0);
        break;
    case 2:
        myMoveToXy(165, 150);
        break;
    case 3:
        myMoveToXy(28, 150);
        break;
    }
}
static void levelingShowMove()
{
    void lcd_menu_bed_leveling_run();
    lcd_info_screen(NULL, NULL, PSTR("Mannual bed leveling"));
    lcd_lib_draw_string_centerP(10, PSTR("Moving..."));
    lcd_lib_draw_string_centerP(20, PSTR("Go to next point"));
    lcd_lib_update_screen();
    if (!planner.blocks_queued())
    {
        if (manual_probe_index == 3)lcd_change_to_menu(lcd_menu_bed_leveling_complete);
        else lcd_change_to_menu(lcd_menu_bed_leveling_run);
    }
}
void lcd_menu_bed_leveling_run()
{
    LED_GLOW();
    if (lcd_lib_encoder_pos == ENCODER_NO_SELECTION)
        lcd_lib_encoder_pos = 0;
    if ( lcd_lib_encoder_pos != 0 && planner.movesplanned() < 4)
    {
        current_position[Z_AXIS] -= float(lcd_lib_encoder_pos) * 0.05;
        planner.buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], 60, 0);
    }
    lcd_lib_encoder_pos = 0;
    if (planner.movesplanned() > 0)
        lcd_info_screen(NULL, NULL, PSTR("CONTINUE"));
    else
        lcd_info_screen(levelingShowMove, levelingMove, PSTR("CONTINUE"));
    lcd_lib_draw_string_centerP(10, PSTR("Rotate the button"));
    lcd_lib_draw_string_centerP(20, PSTR("until the nozzle is"));
    lcd_lib_draw_string_centerP(30, PSTR("a millimeter away"));
    lcd_lib_draw_string_centerP(40, PSTR("from the buildplate."));
    lcd_lib_update_screen();
}
static void lcd_menu_bed_leveling_homingAndStart()
{
    lcd_info_screen(NULL, NULL, PSTR("Mannual bed leveling"));
    lcd_lib_draw_string_centerP(20, PSTR("Homing..."));
    lcd_lib_update_screen();
    if (axis_homed[X_AXIS] && axis_homed[Y_AXIS] && axis_homed[Z_AXIS])
        lcd_change_to_menu(lcd_menu_bed_leveling_run);
}
void bed_leveling_home_move()
{
    axis_homed[X_AXIS] = axis_homed[Y_AXIS] = axis_homed[Z_AXIS] = false;
    mbl.reset();
    reset_bed_level();
    enqueue_and_echo_commands_P(PSTR("M500"));
    enqueue_and_echo_commands_P(PSTR("G28"));
    manual_probe_index = 0;
}
static void manualLevelConfirm()
{
    lcd_question_screen(lcd_menu_bed_leveling_homingAndStart, bed_leveling_home_move, PSTR("YES"), lcd_menu_main, NULL, PSTR("NO"));
    lcd_lib_draw_stringP(0, 10, PSTR("Manual leveling will"));
    lcd_lib_draw_stringP(0, 20, PSTR("reset the leveling pa"));
    lcd_lib_draw_stringP(0, 30, PSTR("rameters,do you conti"));
    lcd_lib_draw_stringP(0, 40, PSTR("nue ?"));
    lcd_lib_update_screen();
}
void lcd_menu_bed_leveling_start()
{
    lcd_question_screen(manualLevelConfirm, NULL, PSTR("CONTINUE"), lcd_menu_main, NULL, PSTR("CANCEL"));
    lcd_lib_draw_string_centerP(10, PSTR("I will guide you"));
    lcd_lib_draw_string_centerP(20, PSTR("through the process"));
    lcd_lib_draw_string_centerP(30, PSTR("of adjusting your"));
    lcd_lib_draw_string_centerP(40, PSTR("buildplate."));
    lcd_lib_update_screen();
}
#endif
#if HAS_BED_PROBE && ABL_GRID
static int zoffset_adjust_stage = 0;
static float z_adjusted = 0.0; 
static void lcd_menu_zprobeOffsetFinishMove()
{
    lcd_info_screen(NULL, NULL, PSTR("Zoffset calibrating"));
    lcd_lib_draw_string_centerP(20, PSTR("Finishing..."));
    lcd_lib_update_screen();
    if (zoffset_adjust_stage==3)
    {
        zoffset_adjust_stage = 4;
        zprobe_zoffset += z_adjusted;
        current_position[Z_AXIS] = LOGICAL_Z_POSITION(LCD_PROBE_Z_RANGE+Z_HOMING_HEIGHT);
        planner.buffer_line_kinematic(current_position, MMM_TO_MMS(4*60), active_extruder);
        FunV007();
        enqueue_and_echo_commands_P(PSTR("M500"));
        zoffset_adjust_stage = 5; 
    }
    if (zoffset_adjust_stage==5) 
    {
        lcd_change_to_menu(lcd_menu_maintenance_leveling);
        LED_GLOW(); 
    }
}
static void lcd_menu_zprobeOffsetFinishNotSaveMove()
{
    lcd_info_screen(NULL, NULL, PSTR("Zoffset calibrating"));
    lcd_lib_draw_string_centerP(20, PSTR("Finishing..."));
    lcd_lib_update_screen();
    if (zoffset_adjust_stage==3)
    {
        zoffset_adjust_stage = 4;
        current_position[Z_AXIS] = LOGICAL_Z_POSITION(LCD_PROBE_Z_RANGE+Z_HOMING_HEIGHT);
        planner.buffer_line_kinematic(current_position, MMM_TO_MMS(4*60), active_extruder);
        FunV007();
        zoffset_adjust_stage = 5; 
    }
    if (zoffset_adjust_stage==5) 
    {
        lcd_change_to_menu(lcd_menu_maintenance_leveling);
        LED_GLOW(); 
    }
}
static void zprobeOffsetFinishMoveParaSet()
{
    zoffset_adjust_stage = 3; 
}
void lcd_menu_zprobe_offset_question_save()
{
    lcd_question_screen(lcd_menu_zprobeOffsetFinishMove, zprobeOffsetFinishMoveParaSet, PSTR("YES"), lcd_menu_zprobeOffsetFinishNotSaveMove, zprobeOffsetFinishMoveParaSet, PSTR("NO"));
    lcd_lib_draw_string_centerP(10, PSTR("Would you like to"));
    lcd_lib_draw_string_centerP(20, PSTR("save the zoffset"));
    lcd_lib_draw_string_centerP(30, PSTR("para you calibrate"));
    lcd_lib_draw_string_centerP(40, PSTR("to the machine?"));
    lcd_lib_update_screen();
}
void lcd_menu_zprobe_offset_run()
{
    if (lcd_lib_encoder_pos == ENCODER_NO_SELECTION)
        lcd_lib_encoder_pos = 0;
    if ( lcd_lib_encoder_pos != 0 && planner.movesplanned() < 4)
    {      
        current_position[Z_AXIS] -= float(lcd_lib_encoder_pos) * 0.05;
        z_adjusted -= float(lcd_lib_encoder_pos) * 0.05;
        planner.buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], 60, 0);
    }
    lcd_lib_encoder_pos = 0;
    if (planner.movesplanned() > 0)
        lcd_info_screen(NULL, NULL, PSTR("CONTINUE"));
    else
        lcd_info_screen(lcd_menu_zprobe_offset_question_save, NULL, PSTR("CONTINUE"));
    lcd_lib_draw_string_centerP(10, PSTR("Rotate the button"));
    lcd_lib_draw_string_centerP(20, PSTR("until the nozzle is"));
    lcd_lib_draw_string_centerP(30, PSTR("a millimeter away"));
    lcd_lib_draw_string_centerP(40, PSTR("from the buildplate."));
    lcd_lib_update_screen();
}
void zprobe_offset_home_move()
{
    axis_homed[X_AXIS] = axis_homed[Y_AXIS] = axis_homed[Z_AXIS] = false;
    gcode_G28(true);
    stepper.synchronize();
    current_position[X_AXIS] = X_CENTER;
    current_position[Y_AXIS] = Y_CENTER;
    planner.buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], MMM_TO_MMS(HOMING_FEEDRATE_XY), active_extruder);
    homeZ();
    current_position[Z_AXIS] = 0;
    planner.buffer_line(current_position[X_AXIS], current_position[Y_AXIS],  current_position[Z_AXIS], current_position[E_AXIS], MMM_TO_MMS(HOMING_FEEDRATE_Z), active_extruder);
    stepper.synchronize();
    zoffset_adjust_stage = 2; 
}
static void zprobe_offset_para_init()
{
    zoffset_adjust_stage = 0; 
}
static void lcd_menu_zprobe_offset_homingAndStart()
{
    lcd_info_screen(NULL, NULL, PSTR("Zoffset calibrating"));
    lcd_lib_draw_string_centerP(20, PSTR("Preparing..."));
    lcd_lib_update_screen();
    if (zoffset_adjust_stage==0)
    {
        zoffset_adjust_stage = 1;
        zprobe_offset_home_move();
    }
    if (zoffset_adjust_stage==2) 
    {
        lcd_lib_encoder_pos = 0;
        z_adjusted = 0.0;
        disable_X();
        disable_Y();
        lcd_change_to_menu(lcd_menu_zprobe_offset_run);
    }
}
void lcd_menu_zprobe_offset_calibrate_start()
{
    lcd_question_screen(lcd_menu_zprobe_offset_homingAndStart, zprobe_offset_para_init, PSTR("CONTINUE"), lcd_menu_main, NULL, PSTR("CANCEL"));
    lcd_lib_draw_string_centerP(10, PSTR("I will guide you"));
    lcd_lib_draw_string_centerP(20, PSTR("through the process"));
    lcd_lib_draw_string_centerP(30, PSTR("of adjusting your"));
    lcd_lib_draw_string_centerP(40, PSTR("zprobe offset para."));
    lcd_lib_update_screen();
}
#endif
