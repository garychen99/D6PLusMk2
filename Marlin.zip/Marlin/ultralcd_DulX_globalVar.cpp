#include "ultralcd_DulX_globalVar.h"
