#include "ultralcd.h"
#include "UltiLCD2_gsh.h"
#include "UltiLCD2_hi_lib.h"
#include "UltiLCD2_menu_material.h"
#include "UltiLCD2_menu_print.h"
#include "UltiLCD2_menu_first_run.h"
#include "UltiLCD2_menu_maintenance.h"
#include "cardreader.h"
#include "temperature.h"
#include "pins.h"
#include "Lifetime_stats.h"
#define lcd_setPage(x)  lcd_change_to_menu(x)
#if FAN_COUNT > 0
extern int fanSpeeds[];
#endif
#define SERIAL_CONTROL_TIMEOUT 5000
#define ALPHA 0.05f
#define ONE_MINUS_ALPHA 0.95f
unsigned long lastSerialCommandTime;
bool serialScreenShown;
uint8_t led_brightness_level = 100;
uint8_t led_mode = LED_MODE_ALWAYS_ON;
float dsp_temperature[EXTRUDERS] = { 20.0 };
float dsp_temperature_bed = 20.0;
#if PIN_EXISTS(SD_DETECT)
  uint8_t lcd_sd_status;
#endif
static void lcd_menu_startup();
#ifdef SPECIAL_STARTUP
static void lcd_menu_special_startup();
#endif
static void lcd_menu_breakout();
static void FunV042();
void lcd_init()
{
    #if ENABLED(SDSUPPORT) && PIN_EXISTS(SD_DETECT)
    SET_INPUT_PULLUP(SD_DETECT_PIN);
    lcd_sd_status = 2; 
    #endif
    lcd_lib_init();
    if (!lcd_material_verify_material_settings())
    {
        lcd_material_reset_defaults();
        for(uint8_t e=0; e<EXTRUDERS; e++)
            lcd_material_set_material(0, e);
    }
    lcd_material_read_current_material();
    currentMenu = lcd_menu_startup;
    analogWrite(LED_PIN, 255 * led_brightness_level / 100);
    lastSerialCommandTime = millis() - SERIAL_CONTROL_TIMEOUT;
}
void lcd_update()
{
    FunV042();
    if (!lcd_lib_update_ready()) return;
    lcd_lib_buttons_update();
#if ENABLED(SDSUPPORT) && PIN_EXISTS(SD_DETECT)
    const bool sd_status = IS_SD_INSERTED;
    if (sd_status != lcd_sd_status && lcd_detected()) {
      if (sd_status) {
        card.release();
      }
      else {
        card.initsd();
      }
      lcd_sd_status = sd_status;
    }
#endif 
    if (led_glow_dir)
    {
        led_glow -= 2;
        if (led_glow == 0) led_glow_dir = 0;
    }
    else{
        led_glow += 2;
        if (led_glow == 126) led_glow_dir = 1;
    }
    millis_t tnow = millis();
    if (IsStopped())
    {
        lcd_lib_clear();
        lcd_lib_draw_string_centerP(10, PSTR("ERROR - STOPPED"));
        lcd_lib_draw_string_centerP(20, PSTR("Please check machine"));
        lcd_lib_draw_stringP(1, 40, PSTR("Go to:"));
        lcd_lib_draw_stringP(1, 50, PSTR("  wanhao3dprinter.com"));
        LED_GLOW_ERROR();
        lcd_lib_update_screen();
    }
    else if (tnow - lastSerialCommandTime < SERIAL_CONTROL_TIMEOUT)
    {
        if (!serialScreenShown)
        {
            lcd_lib_clear();
            lcd_lib_draw_string_centerP(20, PSTR("Printing with USB..."));
            serialScreenShown = true;
        }
        if (GLOBAL_var_V007 == MACRO_var_V01D || GLOBAL_var_V007 == MACRO_var_V01E || GLOBAL_var_V007 == MACRO_var_V01F)
            lastSerialCommandTime = tnow;
        lcd_lib_update_screen();
    }
    else{
        serialScreenShown = false;
        for (uint8_t e = 0; e<EXTRUDERS; e++)
        {
            dsp_temperature[e] = (ALPHA * Temperature::current_temperature[e]) + (ONE_MINUS_ALPHA * dsp_temperature[e]);
        }
        dsp_temperature_bed = (ALPHA * Temperature::current_temperature_bed) + (ONE_MINUS_ALPHA * dsp_temperature_bed);
        currentMenu();
        if (postMenuCheck) postMenuCheck();
    }
    lifetime_stats_tick();
}
static void FunV042()
{
    uint8_t n;
    for (n = 0; n < 16; n++)
    {
        if (GLOBAL_var_V001&(1 << n))
        {
            GLOBAL_var_V001 &= ~((uint16_t)0x0001 << n);
            SERIAL_ECHOLNPAIR("GLOBAL_var_V001",GLOBAL_var_V001);
            break;
        }
    }
    switch(n)
    {
    case MACRO_var_V005:
        #ifdef POW_BREAK_CHECK_PIN
        lcd_setPage(lcd_confirm_continue_print);
        #endif
        break;
    case MACRO_var_V006:
        #ifdef POW_BREAK_CHECK_PIN
        lcd_recontinue_print();
        #endif
        break;
    case MACRO_VAR_V058:
        abortPrint();
        currentMenu = lcd_menu_print_ready;
        SELECT_MAIN_MENU_ITEM(0);
        break;
    }
}
void power_break_interface()
{
    lcd_lib_clear();
    lcd_lib_draw_string_centerP(20, PSTR("Power break!"));
    lcd_lib_draw_string_centerP(40, PSTR("Please restart."));
    lcd_lib_update_screen();
}
static const char*message = nullptr;
void screen_msg()
{
    if (lcd_lib_encoder_pos != ENCODER_NO_SELECTION)
    {
        if (lcd_lib_encoder_pos < 0)
            lcd_lib_encoder_pos += 2 * ENCODER_TICKS_PER_MAIN_MENU_ITEM;
        if (lcd_lib_encoder_pos >= 2 * ENCODER_TICKS_PER_MAIN_MENU_ITEM)
            lcd_lib_encoder_pos -= 2 * ENCODER_TICKS_PER_MAIN_MENU_ITEM;
    }
    if (lcd_lib_button_pressed)
    {
        if (IS_SELECTED_MAIN(0))
        {
            if (previousMenu == lcd_menu_startup)lcd_change_to_menu(lcd_menu_main);
            else lcd_change_to_menu(previousMenu);
        }
    }
    lcd_lib_clear();
    if (message)
    {
        char str[20],i,j;
        const char*t = message;
        for (j = 1; j <= 4; j++)
        {
            memset(str, 0, 20);
            for (i = 0; i < 19 && *t; i++)
            {
                if (*t == '\n')
                {
                    t++;
                    break;
                }
                str[i] = *t;
                t++;
            }
            lcd_lib_draw_string(4, 10 * j, str);
        }
    }
    lcd_lib_draw_box(62 - strlen_P(PSTR("Return.")) * 3, 50, 66 + strlen_P(PSTR("Return.")) * 3, 60);
    if (IS_SELECTED_MAIN(0))
    {
        lcd_lib_set(63 - strlen_P(PSTR("Return.")) * 3, 51, 65 + strlen_P(PSTR("Return.")) * 3, 59);
        lcd_lib_clear_stringP(64 - strlen_P(PSTR("Return.")) * 3, 52, PSTR("Return."));
    }
    else 
        lcd_lib_draw_stringP(64 - strlen_P(PSTR("Return.")) * 3, 52, PSTR("Return."));
    lcd_lib_update_screen();
}
void FunV006(const char*msg)
{
    if (currentMenu != screen_msg)lcd_change_to_menu(screen_msg);
    message = msg;
}
void FunV052()
{
    if (currentMenu == screen_msg)lcd_change_to_menu(previousMenu);
}
void lcd_menu_startup()
{
    lcd_lib_encoder_pos = ENCODER_NO_SELECTION;
    LED_GLOW();
    lcd_lib_clear();
    if (led_glow < 84)
    {
        lcd_lib_draw_gfx(0, 0, ultimakerTextGfx);
        delay(2);
    }else{
    }
    lcd_lib_update_screen();
    if (led_mode == LED_MODE_ALWAYS_ON)
        analogWrite(LED_PIN, int(led_glow << 1) * led_brightness_level / 100);
    if (led_glow_dir || lcd_lib_button_pressed)
    {
        if (led_mode == LED_MODE_ALWAYS_ON)
            analogWrite(LED_PIN, 255 * led_brightness_level / 100);
        led_glow = led_glow_dir = 0;
        LED_NORMAL();
        if (lcd_lib_button_pressed)
            lcd_lib_beep();
#ifdef SPECIAL_STARTUP
        currentMenu = lcd_menu_special_startup;
#else
        currentMenu = lcd_menu_main;
#endif
    }
}
#ifdef SPECIAL_STARTUP
static void lcd_menu_special_startup()
{
    LED_GLOW();
    lcd_lib_clear();
    lcd_lib_draw_gfx(7, 12, specialStartupGfx);
    lcd_lib_draw_stringP(3, 2, PSTR("Welcome"));
    lcd_lib_draw_string_centerP(47, PSTR("To the WANHAO"));
    lcd_lib_draw_string_centerP(55, PSTR("experience!"));
    lcd_lib_update_screen();
    if (lcd_lib_button_pressed)
    {
        if (!IS_FIRST_RUN_DONE())
        {
            lcd_change_to_menu(lcd_menu_first_run_init);
        }else{
            lcd_change_to_menu(lcd_menu_main);
        }
    }
}
#endif
void doCooldown()
{
    for(uint8_t n=0; n<EXTRUDERS; n++)
        Temperature::setTargetHotend(0, n);
    Temperature::setTargetBed(0);
#if FAN_COUNT > 0
    for(char i=0;i<FAN_COUNT;i++)fanSpeeds[i] = 0;
#endif
}
void lcd_menu_main()
{
    lcd_tripple_menu(PSTR("PRINT"), PSTR("MATERIAL"), PSTR("MAINTENANCE"));
    if (lcd_lib_button_pressed)
    {
        if (IS_SELECTED_MAIN(0))
        {
            lcd_clear_cache();
            card.release();
            lcd_change_to_menu(lcd_menu_print_select, SCROLL_MENU_ITEM_POS(0));
        }
        else if (IS_SELECTED_MAIN(1))
            lcd_change_to_menu(lcd_menu_material);
        else if (IS_SELECTED_MAIN(2))
            lcd_change_to_menu(lcd_menu_maintenance);
    }
    if (lcd_lib_button_down && lcd_lib_encoder_pos == ENCODER_NO_SELECTION)
    {
        led_glow_dir = 0;
        if (led_glow > 200)
            lcd_change_to_menu(lcd_menu_breakout);
    }else{
        led_glow = led_glow_dir = 0;
    }
    lcd_lib_update_screen();
}
#define BREAKOUT_PADDLE_WIDTH 21
#define ball_x (*(int16_t*)&lcd_cache[3*5])
#define ball_y (*(int16_t*)&lcd_cache[3*5+2])
#define ball_dx (*(int16_t*)&lcd_cache[3*5+4])
#define ball_dy (*(int16_t*)&lcd_cache[3*5+6])
static void lcd_menu_breakout()
{
    if (lcd_lib_encoder_pos == ENCODER_NO_SELECTION)
    {
        lcd_lib_encoder_pos = (128 - BREAKOUT_PADDLE_WIDTH) / 2 / 2;
        for(uint8_t y=0; y<3;y++)
            for(uint8_t x=0; x<5;x++)
                lcd_cache[x+y*5] = 3;
        ball_x = 0;
        ball_y = 57 << 8;
        ball_dx = 0;
        ball_dy = 0;
    }
    if (lcd_lib_encoder_pos < 0) lcd_lib_encoder_pos = 0;
    if (lcd_lib_encoder_pos * 2 > 128 - BREAKOUT_PADDLE_WIDTH - 1) lcd_lib_encoder_pos = (128 - BREAKOUT_PADDLE_WIDTH - 1) / 2;
    ball_x += ball_dx;
    ball_y += ball_dy;
    if (ball_x < 1 << 8) ball_dx = abs(ball_dx);
    if (ball_x > 124 << 8) ball_dx = -abs(ball_dx);
    if (ball_y < (1 << 8)) ball_dy = abs(ball_dy);
    if (ball_y < (3 * 10) << 8)
    {
        uint8_t x = (ball_x >> 8) / 25;
        uint8_t y = (ball_y >> 8) / 10;
        if (lcd_cache[x+y*5])
        {
            lcd_cache[x+y*5]--;
            ball_dy = abs(ball_dy);
            for(y=0; y<3;y++)
            {
                for(x=0; x<5;x++)
                    if (lcd_cache[x+y*5])
                        break;
                if (x != 5)
                    break;
            }
            if (x==5 && y==3)
            {
                for(y=0; y<3;y++)
                    for(x=0; x<5;x++)
                        lcd_cache[x+y*5] = 3;
            }
        }
    }
    if (ball_y > (58 << 8))
    {
        if (ball_x < (lcd_lib_encoder_pos * 2 - 2) << 8 || ball_x > (lcd_lib_encoder_pos * 2 + BREAKOUT_PADDLE_WIDTH) << 8)
            lcd_change_to_menu(lcd_menu_main);
        ball_dx += (ball_x - ((lcd_lib_encoder_pos * 2 + BREAKOUT_PADDLE_WIDTH / 2) * 256)) / 64;
        ball_dy = -512 + abs(ball_dx);
    }
    if (ball_dy == 0)
    {
        ball_y = 57 << 8;
        ball_x = (lcd_lib_encoder_pos * 2 + BREAKOUT_PADDLE_WIDTH / 2) << 8;
        if (lcd_lib_button_pressed)
        {
            ball_dx = -256 + lcd_lib_encoder_pos * 8;
            ball_dy = -512 + abs(ball_dx);
        }
    }
    lcd_lib_clear();
    for(uint8_t y=0; y<3;y++)
        for(uint8_t x=0; x<5;x++)
        {
            if (lcd_cache[x+y*5])
                lcd_lib_draw_box(3 + x*25, 2 + y * 10, 23 + x*25, 10 + y * 10);
            if (lcd_cache[x+y*5] == 2)
                lcd_lib_draw_shade(4 + x*25, 3 + y * 10, 22 + x*25, 9 + y * 10);
            if (lcd_cache[x+y*5] == 3)
                lcd_lib_set(4 + x*25, 3 + y * 10, 22 + x*25, 9 + y * 10);
        }
    lcd_lib_draw_box(ball_x >> 8, ball_y >> 8, (ball_x >> 8) + 2, (ball_y >> 8) + 2);
    lcd_lib_draw_box(lcd_lib_encoder_pos * 2, 60, lcd_lib_encoder_pos * 2 + BREAKOUT_PADDLE_WIDTH, 63);
    lcd_lib_update_screen();
}
void lcd_buttons_update()
{
    lcd_lib_buttons_update_interrupt();
}
