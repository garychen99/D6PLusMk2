#define BOARD_NAME "Gen7 v1.3"
#define GEN7_VERSION 13 
#include "pins_GEN7_12.h"
